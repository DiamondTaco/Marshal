class TokenizationException(message: String? = null) : Throwable(message)
class ParseException(message: String? = null) : Throwable(message)